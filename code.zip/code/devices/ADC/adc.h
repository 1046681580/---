#define uchar unsigned char
#define uint unsigned int	
void ADC_Init(void);
uint AD_Read(uchar ad,uchar channel);
uint AD_Sample(uchar,uchar);
