#ifndef __USART_H_
#define __USART_H_
#define USART1 1
#define USART2 0
#if  USART1
void init_serialcom_1();
void send_char_com_1(unsigned char ch);
void SendString_1(char *s);
#endif
#if  USART2
void init_serialcom_2();
void send_char_com_2(unsigned char ch);
void SendString_2(char *s);
#endif

#endif
